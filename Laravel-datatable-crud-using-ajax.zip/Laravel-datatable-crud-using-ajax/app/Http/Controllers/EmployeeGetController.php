<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\empdetails;
use Yajra\DataTables\Facades\DataTables;

class EmployeeGetController extends Controller
{
    //
    public function index()
    {


      try
      {

          $empdetails = empdetails::select(['id','empname', 'designation', 'email', 'phone'])->orderby('id','desc');
          //print_r($empdetails);

          return DataTables::of($empdetails)
              ->addColumn('action', function ($empdetails) {
                  return '<button emp_id="' . $empdetails->id . '" class="btn btn-sm btn-primary edit">
                  <i class="glyphicon glyphicon-edit"></i> Edit</button>
                   <button emp_id="' . $empdetails->id . '" class="btn btn-sm btn-danger delete"><i class="glyphicon glyphicon-trash"></i> Delete</button>';
              })
              ->make(true);
      } catch (\Exception $e) {
          dd($e->getMessage());
      }


    }
}
