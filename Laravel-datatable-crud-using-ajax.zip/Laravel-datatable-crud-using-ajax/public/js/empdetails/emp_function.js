"use strict";

$(function () {
        $.ajaxSetup({
            headers: { 'X-CSRF-Token' : $('meta[name=_token]').attr('content') }
        });
  $('#employee-table').DataTable({
    processing: true,
    serverSide: true,
    ajax: 'emp/get_data',
    columns: [{
            data: 'empname'
        },
        {
            data: 'designation'
        },
        {
            data: 'email'
        },
        {
            data: 'phone'
        },
        {
            data: 'action',
            orderable: false,
            searchable: false
        }
    ]


  });

  function token() {
      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
  }

  $('.create').click(function(){
        $('#form_output').html('');
        $('#modalAdd').modal('show');
        $('.modal-title').text('Add Employee Details');
        $('#stores')[0].reset();
  });

  $('#stores').on('submit', function(event){

        token();
        event.preventDefault();
        var form_data = $(this).serialize();
        $.ajax({
            url:"empcont/create",
            method:"POST",
            data:form_data,
            dataType:"json",
            success:function(data)
            {

                    $('#form_output').html(data.success);
                    $('#stores')[0].reset();
                    $('#employee-table').DataTable().ajax.reload();

            }
        }) //ajax
    });// submit


    $(document).on('click', '.edit', function(){

        token();
        var id = $(this).attr("emp_id");
        $('.modal-title').text('Edit Employee Details');
        $('#form_output1').html('');
        //alert(id);
        $('#modalEdit').modal('show');
        $.ajax({
            url:"empcont/fetchdata",
            method:'get',
            data:{id:id},
            dataType:'json',
            success:function(data)
            {
               $('#edit_empname').val(data.empname);
               $('#edit_designation').val(data.designation);
               $('#edit_email').val(data.email);
               $('#edit_phone').val(data.phone);
               $('#edit_id').val(id);

            }
        })

    });


    $('#update').on('submit', function(event){
          token();
          event.preventDefault();
          var form_data = $(this).serialize();
          $.ajax({
              url:"empcont/update",
              method:"POST",
              data:form_data,
              dataType:"json",
              success:function(data)
              {
                      $('#form_output1').html(data.success);
                      $('#employee-table').DataTable().ajax.reload(null, false);

              }
          }) //ajax
      });// submit


      $(document).on('click', '.delete', function(){
          var id = $(this).attr('emp_id');
          if(confirm("Are you sure you want to Delete this data?"))
          {
              $.ajax({
                  url:"empcont/removedata",
                  mehtod:"get",
                  data:{id:id},
                  success:function(data)
                  {
                     $('#form_output_index').html(data.success);
                     $('#employee-table').DataTable().ajax.reload(null, false);
                  }
              })
          }
          else
          {
              return false;
          }
     });


});
