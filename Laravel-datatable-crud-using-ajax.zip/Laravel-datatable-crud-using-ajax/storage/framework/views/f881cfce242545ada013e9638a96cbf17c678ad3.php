<?php $__env->startSection('content'); ?>

    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title pull-left">
                Employee Details
            </h3>
            <button class="btn btn-success btn-sm float-right create"><i class="glyphicon glyphicon-plus"></i> Create</button>
            <div class="clearfix"></div>
            <span id="form_output_index"></span>
        </div><br>
        <div class="table-responsive">
            <table id="employee-table" class="table">
                <thead>
                  <tr>
                    <td>Name</td>
                    <td>Deisignation</td>
                    <td>Email</td>
                    <td>Phone</td>
                    <td>Action</td>
                  </tr>
                </thead>

            </table>
        </div>

    </div>


    
    <div id="modalAdd" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">Modal Header</h4>
                </div>
                <form id="stores">
                    <div class="modal-body">
                       <span id="form_output"></span>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" name="empname" placeholder="Enter name" required>
                        </div>
                        <div class="form-group">
                            <label for="cnum">Designation</label>
                            <input type="text" class="form-control" name="designation" placeholder="Enter Designation">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" placeholder="Enter email" required>
                        </div>
                        <div class="form-group">
                            <label for="address">Phone</label>
                            <input type="text" class="form-control" name="phone" placeholder="Enter phone" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Save</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>

        </div>
    </div>


    
    <div id="modalEdit" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Modal Header</h4>
                </div>
                <form id="update">
                    <div class="modal-body">
                        <input type="hidden" name="edit_id" id="edit_id"  class="id">
                        <span id="form_output1"></span>
                         <div class="form-group">
                             <label for="name">Name</label>
                             <input type="text" class="form-control" name="edit_empname" id="edit_empname" placeholder="Enter name" required>
                         </div>
                         <div class="form-group">
                             <label for="cnum">Designation</label>
                             <input type="text" class="form-control" name="edit_designation" id="edit_designation" placeholder="Enter Designation">
                         </div>
                         <div class="form-group">
                             <label for="email">Email</label>
                             <input type="email" class="form-control" name="edit_email" id="edit_email" placeholder="Enter email" required>
                         </div>
                         <div class="form-group">
                             <label for="address">Phone</label>
                             <input type="text" class="form-control" name="edit_phone" id="edit_phone" placeholder="Enter phone" required>
                         </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/empdetails/emp_function.js')); ?>"></script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\crud_datatable\resources\views/index.blade.php ENDPATH**/ ?>