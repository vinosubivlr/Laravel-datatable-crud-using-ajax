<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\empdetails;
use Yajra\DataTables\Facades\DataTables;

class EmployeeController extends Controller
{
    //
    function postdata(Request $request)
   {
          $empdetails = new empdetails([
              'empname'    =>  $request->get('empname'),
              'designation'     =>  $request->get('designation'),
              'email'     =>  $request->get('email'),
              'phone'     =>  $request->get('phone')
          ]);
          $empdetails->save();
          $success_output = '<div class="alert alert-success">Data Inserted</div>';

          $output = array(
            'success'   =>  $success_output
          );

          echo json_encode($output);
   }


    function fetchdata(Request $request)
    {
        $id = $request->get('id');
        $empdetails = empdetails::find($id);
        $output = array(
            'empname'    =>  $empdetails->empname,
            'designation'     =>  $empdetails->designation,
            'email'     =>  $empdetails->email,
            'phone'     =>  $empdetails->phone
        );
        echo json_encode($output);
    }


    function updatedata(Request $request)
   {
        $id = $request->get('edit_id');
        $empdetails = empdetails::find($id);
        $empdetails->empname = $request->get('edit_empname');
        $empdetails->designation = $request->get('edit_designation');
        $empdetails->email = $request->get('edit_email');
        $empdetails->phone = $request->get('edit_phone');
        $empdetails->save();

        $success_output = '<div class="alert alert-success">Data Updated</div>';
        $output = array(
          'success'   =>  $success_output
        );

        echo json_encode($output);
   }

   function removedata(Request $request)
   {
       $empdetails = empdetails::find($request->get('id'));
       if($empdetails->delete())
       {
          $success_output = '<div class="alert alert-success alert-dismissible fade show" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>Record Deleted</div>';

          $output = array(
            'success'   =>  $success_output
          );
       }
       echo json_encode($output);

   }

}
