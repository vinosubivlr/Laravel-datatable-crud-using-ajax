<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class empdetails extends Model
{
    protected $fillable = ['empname', 'designation','email','phone'];
}
