<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('emp/get_data', 'EmployeeGetController@index');

Route::post('empcont/create', 'EmployeeController@postdata');
Route::get('empcont/fetchdata', 'EmployeeController@fetchdata');
Route::post('empcont/update', 'EmployeeController@updatedata');
Route::get('empcont/removedata', 'EmployeeController@removedata');
